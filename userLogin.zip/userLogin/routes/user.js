const bcrypt = require('bcrypt');
const saltRounds = 10;

exports.signup = function(req, res){
    message = '';
    if(req.method == "POST"){
       var post  = req.body;
       var username = post.username;
       var password = post.password;
       var name= post.name;
       const encryptedPassword =  bcrypt.hash(password, saltRounds)
       if(username !='' && password!='') {
           var sql = "INSERT INTO `users`(`name`,`username`, `password`) VALUES ('" + name + "','" + username + "','" + encryptedPassword + "')";
 
           var query = db.query(sql, function(err, result) {
              message = "Your account has been created succesfully.";
              res.render('signup.ejs',{message: message});
           });
       } else {
           message = "Username and password is mandatory field.";
           res.render('signup.ejs',{message: message});
       }
 
    } else {
       res.render('signup');
    }
 };
  
 exports.login = function(req, res){
    var message = '';
    var sess = req.session; 
 
    if(req.method == "POST"){
       var post  = req.body;
       var username = post.username;
       var password= post.password;
      
       var sql="SELECT id, name, username FROM `users` WHERE `username`='"+username+"' and password = '"+password+"'";   
       const comparison =  bcrypt.compare(password, results[0].password) 

       db.query(sql, function(err, results){       
          if(results.length && comparison){
            var sql = "INSERT INTO `login_history`(`user_id`) VALUES ('" + results[0].id + "'')";
 
            var query = db.query(sql, function(err, result) {
             req.session.userId = results[0].id;
             req.session.user = results[0];
            
             res.redirect('/home/dashboard');
          })
          }
          else{
             message = 'You have entered invalid username or password.';
             res.render('index.ejs',{message: message});
          }
                  
       });
    } else {
       res.render('index.ejs',{message: message});
    }
            
 };
 
            
 exports.dashboard = function(req, res, next){
            
    var user =  req.session.user,
    userId = req.session.userId;
    if(userId == null){
       res.redirect("/login");
       return;
    }
 
    var sql="SELECT * FROM `users` as u left join login_history as lh on u.id = lh.user_id  group by u.id  order by DATE(lh.login_date) desc";
 
    db.query(sql, function(err, results){
       res.render('dashboard.ejs', {data:results});    
    });       
 };
 
 exports.listing = function(req, res){
 
    var userId = req.session.userId;
    if(userId == null){
       res.redirect("/login");
       return;
    }
 
    var sql="SELECT * FROM `users` WHERE `id`='"+userId+"'";          
    db.query(sql, function(err, result){  
       res.render('listing.ejs',{data:result});
    });
 };
 
 exports.logout=function(req,res){
    req.session.destroy(function(err) {
       res.redirect("/login");
    })
 };